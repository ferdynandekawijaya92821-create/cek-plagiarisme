def bantu():
    return 1
